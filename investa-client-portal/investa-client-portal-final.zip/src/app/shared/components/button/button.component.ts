import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Type definitions for button variants
 */
type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'outline';

/**
 * Type definitions for button sizes
 */
type ButtonSize = 'sm' | 'md' | 'lg';

/**
 * ButtonComponent
 * 
 * Reusable button component with consistent styling across the application.
 * Supports multiple variants, sizes, and states.
 * 
 * Features:
 * - Multiple variants (primary, secondary, danger, outline)
 * - Three size options (sm, md, lg)
 * - Disabled state support
 * - Full width option
 * - Keyboard accessible (focus ring)
 * - Smooth transitions
 * 
 * @example
 * // Primary button
 * <app-button (clicked)="onAction()">Click me</app-button>
 * 
 * @example
 * // Danger button, disabled
 * <app-button variant="danger" [disabled]="true">Delete</app-button>
 * 
 * @example
 * // Large outline button
 * <app-button variant="outline" size="lg" [fullWidth]="true">Learn More</app-button>
 */
@Component({
  selector: 'app-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button 
      [ngClass]="getButtonClasses()"
      (click)="clicked.emit()"
      type="button"
      [disabled]="disabled"
      class="investa-button-control"
    >
      <ng-content></ng-content>
    </button>
  `,
  styleUrls: ['./button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ButtonComponent {
  /**
   * Visual variant of the button
   * @default 'primary'
   */
  @Input() variant: ButtonVariant = 'primary';

  /**
   * Size of the button
   * @default 'md'
   */
  @Input() size: ButtonSize = 'md';

  /**
   * Whether the button is disabled
   * @default false
   */
  @Input() disabled = false;

  /**
   * Whether the button takes full width of container
   * @default false
   */
  @Input() fullWidth = false;

  /**
   * Emitted when button is clicked
   */
  @Output() clicked = new EventEmitter<void>();

  /**
   * Generates dynamic button CSS classes based on variant and size
   * @returns Array of Tailwind CSS class names
   */
  getButtonClasses(): string[] {
    const sizeClasses: Record<ButtonSize, string[]> = {
      sm: ['investa-btn-sm'],
      md: ['investa-btn-md'],
      lg: ['investa-btn-lg']
    };

    const variantClasses: Record<ButtonVariant, string[]> = {
      primary: ['investa-btn-primary'],
      secondary: ['investa-btn-secondary'],
      danger: ['investa-btn-danger'],
      outline: ['investa-btn-outline']
    };

    return [
      'investa-btn',
      ...sizeClasses[this.size],
      ...variantClasses[this.variant],
      ...(this.disabled ? ['is-disabled'] : []),
      ...(this.fullWidth ? ['w-full'] : [])
    ];
  }
}
