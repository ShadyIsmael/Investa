import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { LanguageService } from '../../services/language.service';
import { NotificationService } from '../../services/notification.service';
import { ClickOutsideDirective } from '../../directives/click-outside.directive';
import { ProfileService } from '../../services/profile.service';
import { RoleContextService } from '../../services/role-context.service';
import { get } from 'lodash-es';

/**
 * AdminNavbarComponent
 * 
 * Navigation bar for authenticated users (admin/investor/founder section).
 * Features:
 * - User role-based navigation links
 * - Notification bell with unread count
 * - User dropdown menu with logout
 * - Language toggle functionality
 * - Real-time notification display
 * 
 * Automatically hides/shows menus when interacting with other dropdowns.
 * Uses Angular Signals for reactive state management.
 * 
 * @example
 * <app-admin-navbar></app-admin-navbar>
 */
@Component({
  selector: 'app-admin-navbar',
  templateUrl: './admin-navbar.component.html',
  styleUrls: ['./admin-navbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, CommonModule, TranslatePipe, ClickOutsideDirective]
})
export class AdminNavbarComponent {
  private authService = inject(AuthService);
  private router: Router = inject(Router);
  languageService = inject(LanguageService);
  notificationService = inject(NotificationService);
  private profileService = inject(ProfileService);
  roleContext = inject(RoleContextService);

  /** Current user's role (investor, founder, admin) */
  userRole = this.authService.userRole;

  /** Avatar URL sourced from the user's profile, with picsum fallback */
  avatarUrl = computed(() => {
    const p = this.profileService.profile();
    if (p?.basicInfo?.avatarUrl) return p.basicInfo.avatarUrl;
    const seed = (p?.basicInfo?.firstName || 'user').replace(/\s+/g, '') || 'user';
    return `https://picsum.photos/seed/${seed}/100/100`;
  });

  /** User's display name */
  userName = computed(() => {
    const p = this.profileService.profile();
    if (p?.basicInfo?.firstName && p?.basicInfo?.lastName) {
      return `${p.basicInfo.firstName} ${p.basicInfo.lastName}`;
    }
    return p?.basicInfo?.firstName || 'User';
  });

  /** User's email address */
  userEmail = computed(() => {
    const p = this.profileService.profile();
    return p?.contactInfo?.email || p?.coreMetrics?.email || '';
  });

  /** User's initials for avatar fallback (e.g., "AM" for Ahmed Mohamed) */
  userInitials = computed(() => {
    const p = this.profileService.profile();
    const firstName = p?.basicInfo?.firstName || '';
    const lastName = p?.basicInfo?.lastName || '';
    if (firstName && lastName) {
      return `${firstName.charAt(0).toUpperCase()}${lastName.charAt(0).toUpperCase()}`;
    }
    if (firstName) {
      return firstName.charAt(0).toUpperCase();
    }
    return 'U';
  });

  /** Whether user has a profile image */
  hasProfileImage = computed(() => {
    const p = this.profileService.profile();
    return !!p?.basicInfo?.avatarUrl;
  });

  /** Unread message count */
  unreadMessageCount = computed(() => {
    return this.notificationService.unreadCount();
  });

  /** Tracks if user dropdown menu is open */
  isUserMenuOpen = signal(false);
  
  /** Tracks if notifications dropdown is open */
  isNotificationsOpen = signal(false);
  
  /** Unread notification count */
  unreadCount = this.notificationService.unreadCount;

  /** Total notification count from backend */
  totalNotificationCount = this.notificationService.totalCount;

  /** Most recent notifications (limited to 10) */
  recentNotifications = computed(() => this.notificationService.notifications().slice(0, 10));

  /**
   * Toggles the user menu dropdown
   * Automatically closes notifications menu when opening user menu
   */
  toggleUserMenu() {
    this.isUserMenuOpen.update(value => !value);
    if (this.isUserMenuOpen()) {
      this.isNotificationsOpen.set(false);
    }
  }
  
  /**
   * Toggles the notifications dropdown
   * Automatically closes user menu when opening notifications menu
   */
  toggleNotifications() {
    this.isNotificationsOpen.update(value => !value);
     if (this.isNotificationsOpen()) {
      this.isUserMenuOpen.set(false);
    }
  }

  /**
   * Logs out the current user and redirects to login page
   */
  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  /**
   * Toggles the application language
   * @param event Click event to prevent default behavior
   */
  toggleLanguage(event: Event) {
    event.preventDefault();
    this.languageService.toggleLanguage();
  }
  
  /**
   * Navigates to the notifications page and closes the dropdown
   */
  viewAllNotifications() {
    this.isNotificationsOpen.set(false);
    this.router.navigate(['/admin/notifications']);
  }

  markAllRead() {
    this.notificationService.markAllAsRead();
  }

  /**
   * Calculates human-readable time difference from current time (localized)
   * @param date The date to calculate time difference from
   * @returns Localized string like "2 hours ago", "3 days ago", etc.
   */
  getTimeAgo(date: Date): string {
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    const dictionary = this.languageService.dictionary();

    let interval = seconds / 31536000;
    if (interval > 1) {
      const years = Math.floor(interval);
      const key = years > 1 ? 'common.timeAgo.years' : 'common.timeAgo.year';
      return get(dictionary, key, `${years} year${years > 1 ? 's' : ''} ago`).replace('{count}', String(years));
    }
    interval = seconds / 2592000;
    if (interval > 1) {
      const months = Math.floor(interval);
      const key = months > 1 ? 'common.timeAgo.months' : 'common.timeAgo.month';
      return get(dictionary, key, `${months} month${months > 1 ? 's' : ''} ago`).replace('{count}', String(months));
    }
    interval = seconds / 86400;
    if (interval > 1) {
      const days = Math.floor(interval);
      const key = days > 1 ? 'common.timeAgo.days' : 'common.timeAgo.day';
      return get(dictionary, key, `${days} day${days > 1 ? 's' : ''} ago`).replace('{count}', String(days));
    }
    interval = seconds / 3600;
    if (interval > 1) {
      const hours = Math.floor(interval);
      const key = hours > 1 ? 'common.timeAgo.hours' : 'common.timeAgo.hour';
      return get(dictionary, key, `${hours} hour${hours > 1 ? 's' : ''} ago`).replace('{count}', String(hours));
    }
    interval = seconds / 60;
    if (interval > 1) {
      const minutes = Math.floor(interval);
      const key = minutes > 1 ? 'common.timeAgo.minutes' : 'common.timeAgo.minute';
      return get(dictionary, key, `${minutes} minute${minutes > 1 ? 's' : ''} ago`).replace('{count}', String(minutes));
    }
    const secs = Math.floor(seconds);
    const key = secs > 1 ? 'common.timeAgo.seconds' : 'common.timeAgo.second';
    return get(dictionary, key, `${secs} second${secs > 1 ? 's' : ''} ago`).replace('{count}', String(secs));
  }
}
